#!/bin/sh

# Correct working directory
cd /opt/opencti-connector-sethsites

# Start the connector
python3 main.py
